# Add the class of your model only
# Here is where you define the architecture of your model using pytorch
